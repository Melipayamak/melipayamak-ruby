require_relative "../../melipayamak/melipayamakapi"

class MpController < ApplicationController
  def rest
	username = 'username'
	password = 'password'
	api = Melipayamakapi.new(username,password)
	sms = api.sms
	to = '09123456789'
	from = '5000...'
	text = 'تست وب سرویس ملی پیامک'
	response = sms.send(to,from,text)
	puts response
  end


  def soap
	username = 'username'
	password = 'password'
	api = Melipayamakapi.new(username,password)
	sms = api.sms('soap')
	to = '09123456789'
	from = '5000...'
	text = 'تست وب سرویس ملی پیامک'
	response = sms.send(to,from,text)
	puts response
  end

end
