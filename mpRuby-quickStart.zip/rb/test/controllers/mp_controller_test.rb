require 'test_helper'

class MpControllerTest < ActionDispatch::IntegrationTest
  test "should get rest" do
    get mp_rest_url
    assert_response :success
  end

end
